# -*- coding: utf-8 -*-
"""
@Author: shinian
@Date:   2024-05-22 15:16:08
@Last Modified by:   shinian
@Last Modified time: 2024-05-22 15:35:28
"""

data = {'1': 1, '3': 3}
l = [data]
print(l)
